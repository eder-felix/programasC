/*
Federal University of Maranhao, April 13, 2019
Version: 1.0
Author: Eder Matheus Silveira Felix. Contact: eder.silveirafelix@gmail.com
Description: This program calculates the factorial of a number using the 
GTK+ user interface... 
The GMP library is used to provide operation with large numbers.
Compile the program with GCC using:
gcc `pkg-config --cflags gtk+-3.0` -o fatorial_UI fatorial_UI.c `pkg-config --libs gtk+-3.0` -lgmp

Documentacao para instalacao do GTK > https://developer.gnome.org/gtk3/stable/gtk-building.html
Documentacao para instalacao do GMP > https://gmplib.org/manual/

*/

/*include files
*/
#include<gmp.h>
#include<stdio.h>
#include<errno.h>
#include<string.h>
#include<stdlib.h>
#include <gtk/gtk.h>
/*Defines
*
*/
#define MAX_SIZE 2048
#define DECIMAL_BASE 10

struct message_passing{
	char _text_result[MAX_SIZE];
	GtkBuilder *_builder;
};
/*factorial function
Description: this function calculates the factorial of the number mpz_t num
by using recursivity
*/
void factorial (mpz_t num, mpz_t result){
	/*if num < 0 then result = 0*/
	if(mpz_cmp_ui(num,0)<0) mpz_init(result);
	else{
		mpz_init(result);
		mpz_set_ui(result, 1);
		
		/*while num > 0*/		
		while(mpz_cmp_ui(num,0)>0){
			mpz_mul(result, result, num);
			mpz_sub_ui(num, num, 1);
		}
	}
}
/*calc button event handle
 *this function takes what is on the entry to calculate
 *the factorial
 *
 */
static void calc_event_handle(GtkWidget *widget, gpointer data){
	mpz_t num_t;
	mpz_t result;
	/*
	 * type casting the data
	 */
	struct message_passing* data_msg = (struct message_passing*)data;

	GtkBuilder *builder = data_msg->_builder;
	char *text_result = data_msg->_text_result;

	/*
	 * getting objects
	 */
	GObject *textbuffer = gtk_builder_get_object(builder, "buff");
	GObject *_entry = gtk_builder_get_object(builder,"entry");
	
	/* getting text from text entry
	 */
	char *text_entry = gtk_entry_get_text(GTK_ENTRY(_entry));

	/*
	 * verify if the entry is valid
	 */
	int mpz_t_init_result = mpz_init_set_str(num_t, text_entry, DECIMAL_BASE);
	if(mpz_t_init_result == -1){
		strcpy(text_result,"Invalid Entry!!");
	}
	else{
		factorial(num_t, result);
		gmp_sprintf(text_result,"%Zd",result);
	}
	
	gtk_text_buffer_set_text (GTK_TEXT_BUFFER(textbuffer), text_result,-1);
	//printf("Text: %s\n",text_entry);
}

/*configure User Interface function
 *
 *
 */
void configure_ui(struct message_passing *message){
	GObject *window;
	GObject *button;
	GtkBuilder *builder = message->_builder;
	window = gtk_builder_get_object(builder,"window");
	/*
	if the main window is closed, the execution is terminated*/
	g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	button = gtk_builder_get_object(builder,"calc");
	g_signal_connect(button, "clicked", G_CALLBACK(calc_event_handle), message);
	gtk_main();
}
/*main function
Description: Reads an number from a file, and writes the factorial of the number
to another file
*/

int main(int argc, char *argv[]){
	/*Local variables*/
	struct message_passing *msg = (struct message_passing*) malloc(sizeof(struct message_passing));
	GtkBuilder *builder;
	GError *error = NULL;
	char num[MAX_SIZE];
	mpz_t num_t;
	mpz_t result_t;	/*the factorial result will be saved here*/
	gtk_init(&argc, &argv);

	/*Construct a GTK Builder instance and load a UI from a xml file
	 *
	 */
	builder = gtk_builder_new();
	if(gtk_builder_add_from_file (builder, "GUI02.ui", &error)==0){
		g_printerr ("Error loading file: %s\n", error->message);
		g_clear_error (&error);
      		return 1;
	}
	msg->_builder = builder;
	configure_ui(msg);
	
}
